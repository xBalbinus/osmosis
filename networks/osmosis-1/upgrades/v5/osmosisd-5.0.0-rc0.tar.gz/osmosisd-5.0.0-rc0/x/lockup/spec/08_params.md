<!--
order: 8
-->

# Parameters

The lockup module contains the following parameters:

| Key                    | Type            | Example |
| ---------------------- | --------------- | ------- |

Note:
Currently no parameters are set for `lockup` module, we will need to move lockable durations from incentives module to lockup module.
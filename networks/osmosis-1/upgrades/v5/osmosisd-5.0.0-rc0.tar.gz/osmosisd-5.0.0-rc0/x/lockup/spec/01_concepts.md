<!--
order: 1
-->

# Concepts

The purpose of `lockup` module is to provide the functionality to lock tokens for specific period of time for LP token stakers to get incentives.

This module provides interfaces for other modules to iterate the locks efficiently and grpc query to check the status of locked coins.

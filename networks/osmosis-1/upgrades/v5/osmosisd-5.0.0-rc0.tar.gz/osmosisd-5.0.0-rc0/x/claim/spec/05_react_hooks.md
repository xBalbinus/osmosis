<!--
order: 5
-->

# React Hooks

Claim module react on following hooks of external modules.

20% of airdrop is given when `staking.AfterDelegationModified` hook is triggered.
20% of airdrop is given when `governance.AfterProposalVote` hook is triggered.
20% of airdrop is given when `gamm.AfterSwap` hook is triggered.
20% of airdrop is given when `gamm.AfterPoolCreated` or `gamm.AfterJoinPool` hook is triggered.

When airdrop is claimed for specific hook type, it can't be claimed double.

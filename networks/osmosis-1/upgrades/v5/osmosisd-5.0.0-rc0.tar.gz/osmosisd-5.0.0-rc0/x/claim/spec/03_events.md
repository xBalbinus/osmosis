<!--
order: 3
-->

# Events

## External module hooks

`claim` module emits the following events at the time of hooks:

| Type  | Attribute Key | Attribute Value |
| ----- | ------------- | --------------- |
| claim | sender        | {receiver}      |
| claim | amount        | {claim_amount}  |


<!--
order: 1
-->

# Concepts

The purpose of `epochs` module is to provide generalized epoch interface to other modules so that they can easily implement epochs without keeping own code for epochs.

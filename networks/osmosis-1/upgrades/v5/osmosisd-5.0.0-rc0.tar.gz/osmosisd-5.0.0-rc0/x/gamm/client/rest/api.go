package rest

import (
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/gorilla/mux"
)

func RegisterHandlers(ctx client.Context, r *mux.Router) {
	// TODO
}

# CLI docs

TODO add an index here explaining each tx type

- [`create-pool`](./create-pool.md)
- [`create-lbp-pool`](./create-lbp-pool.md)

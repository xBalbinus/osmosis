#!/usr/bin/env bash

make build
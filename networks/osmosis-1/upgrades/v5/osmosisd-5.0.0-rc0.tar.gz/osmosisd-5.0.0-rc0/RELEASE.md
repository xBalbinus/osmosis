# Making releases

run

```sh
make distclean build-reproducible
```

and then upload the binaries from the artifacts folder.

